package com.example.demoviewpager2.model

data class Item(var image: Int)
